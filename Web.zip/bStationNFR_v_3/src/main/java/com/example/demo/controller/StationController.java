package com.example.demo.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.example.demo.model.Station;
import com.example.demo.model.User;
import com.example.demo.service.StationService;

@Controller
@SessionAttributes(value = "user")
public class StationController {

	@Autowired
	private StationService stationService;

	@GetMapping("/info")
	public String goToInfo(Model model, HttpSession session) {
		if(((User) model.getAttribute("user")).getLogin() == null) {
			return "redirect:/";
		}
		List<Station> stations = new ArrayList<>();
		stations = stationService.findAllByNameContains("");
		model.addAttribute("stations1", stations);
		return "info";
	}

	@GetMapping("/searchByName")
	public String searchByName(@ModelAttribute("nameStation") String name, Model model) {
		if(((User) model.getAttribute("user")).getLogin() == null) {
			return "redirect:/";
		}
		List<Station> stations = new ArrayList<Station>();
		stations = stationService.findAllByNameContains(name);

		model.addAttribute("stations1", stations);

		return "info";
	}

	@GetMapping("/addSt")
	public String addSt(Model model) {
		if(((User) model.getAttribute("user")).getLogin() == null) {
			return "redirect:/";
		}
		model.addAttribute("station", new Station());
		return "addStation";
	}

	
	
	@PostMapping("/updateStation")
	public String addStation(@Valid @ModelAttribute Station station, BindingResult res, Model model) {
		if(((User) model.getAttribute("user")).getLogin() == null) {
			return "redirect:/";
		}
		if (res.hasErrors()) {
			return "addStation";
		}
		
		boolean isName = false;
		List<Station> stations = stationService.getAll();
		Iterator<Station> iterator = stations.iterator();
		while (iterator.hasNext()) {
			Station stationNext = iterator.next();
			if(stationNext.getName().equals(station.getName()) && stationNext.getCodeStation() == station.getCodeStation()) {
				isName = true;
				System.out.println(isName);
				break;
			}
		}
			
		
		
		if(isName){
			model.addAttribute("missStation", "missStation");
			return "addStation";
		}
		
		stationService.save(station);
		model.addAttribute("station1", new Station());
		List<Station> station1 = new ArrayList<>();
		model.addAttribute("stations1", station1);
		return "info";
	}

	@GetMapping("/updateSt/{id}")
	public String updatete(@PathVariable Long id, Model model) {
		if(((User) model.getAttribute("user")).getLogin() == null) {
			return "redirect:/";
		}
		Optional<Station> station = stationService.getById(id);
		model.addAttribute("station", station.get());
		return "addStation";
	}

	@GetMapping("/deleteSt/{id}")
	public String delete(@PathVariable Long id, Model model) {
		if(((User) model.getAttribute("user")).getLogin() == null) {
			return "redirect:/";
		}
		stationService.remove(id);
		List<Station> station = new ArrayList<>();
		model.addAttribute("stations1", station);
		return "redirect:/info";
	}

}
