package com.example.demo.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.example.demo.model.Client;
import com.example.demo.model.Station;
import com.example.demo.model.User;
import com.example.demo.service.ClientService;
import com.example.demo.service.StationService;

@Controller
@SessionAttributes(value = "user")
public class ClientsController {

	@Autowired
	private ClientService clientsService;
	
	@Autowired
	private StationService stationService;

		
	@GetMapping("/addClients/{id}")
	public String addClients(@PathVariable Long id, Model model) {
		if(((User) model.getAttribute("user")).getLogin() == null) {
			return "redirect:/";
		}
		Station station = stationService.getById(id).get();
		Client client = new Client();
		model.addAttribute("station", station);
		model.addAttribute("client", client);
		return "addClients.html";
	}

	@PostMapping("/addClients/{id}")
	public String addClientsPost(@Valid @ModelAttribute Client client, BindingResult res, @PathVariable Long id, Model model) {
		if(((User) model.getAttribute("user")).getLogin() == null) {
			return "redirect:/";
		}
		Station station = stationService.getById(id).get();
		if (res.hasErrors()) {
			
			model.addAttribute("station", station);
			model.addAttribute("client", client);
			return "addClients";
		}
		clientsService.save(client, station);
		List<Station> stations = new ArrayList<>();
		model.addAttribute("stations1", stations);
		return "redirect:/info";
	}
	
	@GetMapping("/updateCl/{id}")
	public String updateClients(@PathVariable String id, Model model) {
		if(((User) model.getAttribute("user")).getLogin() == null) {
			return "redirect:/";
		}
		model.addAttribute("station", clientsService.getById(Long.parseLong(id)).getStation());
		model.addAttribute("client", clientsService.getById(Long.parseLong(id)));
		return "addClients";
	}
	
	@GetMapping("/deleteCl/{id1}/{id2}")
	public String deleteClients(@PathVariable Long id1, @PathVariable Long id2, Model model) {
		if(((User) model.getAttribute("user")).getLogin() == null) {
			return "redirect:/";
		}
		Station station = stationService.getById(id2).get();
		station.getClients().remove(clientsService.getById(id1));
		stationService.save(station);
		return "redirect:/info";
	}
	
	@GetMapping("/kalk")
	public String goToKalk(Model model) {
		if(((User) model.getAttribute("user")).getLogin() == null) {
			return "redirect:/";
		}
		List<Client> clients = new ArrayList<Client>(); 
		  List<Station> stations = stationService.findAllByNameContains("");
		  Double[] price = new Double[12];
		  model.addAttribute("clients", clients);
		  model.addAttribute("stations" ,stations);
		  model.addAttribute("price", price);
		  model.addAttribute("client1", new Client());
		return "kalk";
	}
	@GetMapping("/kalk/{id}")
	public String goToKalk(@PathVariable Long id, Model model) {
		if(((User) model.getAttribute("user")).getLogin() == null) {
			return "redirect:/";
		}
		List<Client> clients = new ArrayList<Client>(); 
		  List<Station> stations = stationService.findAllByNameContains("");
		  Client client1 = clientsService.getById(id);
		  Double dist = client1.getDistance();
			int[] day = {31,28,31,30,31,30,31,31,30,31,30,31};
			Double[] price = new Double[12];
			for (int i = 0; i < price.length; i++) {
				price[i] = dist * day[i];
			}
		  
		  model.addAttribute("clients", clients);
		  model.addAttribute("stations" ,stations);
		  model.addAttribute("price", price);
		  model.addAttribute("client1", client1);
		return "kalk";
	}
	
	@GetMapping("/kalkP")
	public String searchByName(@ModelAttribute("selectClient") String name, Model model) {
		if(((User) model.getAttribute("user")).getLogin() == null) {
			return "redirect:/";
		}
		Client client1 = clientsService.getByName(name);
		
		Double dist = client1.getDistance();
		int[] day = {31,28,31,30,31,30,31,31,30,31,30,31};
		Double[] price = new Double[12];
		for (int i = 0; i < price.length; i++) {
			price[i] = dist * day[i];
		}
		System.out.println(price);
		List<Client> clients = new ArrayList<Client>(); 
		  List<Station> stations = stationService.findAllByNameContains("");
		  model.addAttribute("clients", clients);
		  model.addAttribute("stations" ,stations);
		   model.addAttribute("client1", client1);
		model.addAttribute("price", price);

		return "kalk";
	}
	
	

}
