package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import com.example.demo.model.Station;

public interface StationService {
	
	boolean save (Station station);
	
	boolean remove(Long id);
	
	List<Station> getAll();
	
	Optional<Station> getById(Long id);
	
	List<Station> findAllByName(String word); 
	
	List<Station> findAllByNameContains(String name);

	List<Station> getByName(String name);

	List<Station> findFirst3By();


}
