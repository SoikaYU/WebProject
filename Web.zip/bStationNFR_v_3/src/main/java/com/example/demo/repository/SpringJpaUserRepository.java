package com.example.demo.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

import com.example.demo.model.Station;
import com.example.demo.model.User;

@Repository
public interface SpringJpaUserRepository  extends CrudRepository<User,Long>{
	
	public User findByLogin(String login);

	

}
