package com.example.demo.service;

import java.util.List;

import com.example.demo.model.User;

public interface UserService {
	
	boolean save(User user);
	
	boolean remove(Long id);

	List<User> getAll();
	
	User getById(Long id);
	
	
	User getByName(String login);

}
