package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Client;
import com.example.demo.model.Station;

public interface ClientService {
	
	boolean save(Client client, Station station);

	boolean remove(Long id);

	List<Client> getAll();

	Client getById(Long id);

	boolean remove(Client client);
	
	Client getByName(String name);
	

}
