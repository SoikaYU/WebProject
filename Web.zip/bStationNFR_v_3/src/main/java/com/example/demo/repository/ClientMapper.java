package com.example.demo.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.example.demo.model.Client;
import com.example.demo.model.User;

@Component
public class ClientMapper implements RowMapper<Client>{

	@Override
	public Client mapRow(ResultSet rs, int rowNum) throws SQLException {
		Client client = new Client();
		client.setId(rs.getLong("id"));
		client.setName(rs.getString("name"));
		client.setCodeClient(rs.getInt("code_client"));
		client.setDistance(rs.getDouble("distance"));
		
		
		
		return client;
	}

}
