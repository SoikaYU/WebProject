package com.example.demo.service;

import java.util.List;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;


import com.example.demo.model.User;
import com.example.demo.repository.SpringJpaUserRepository;

@Service
public class UserServiceImpl implements  UserService{
	
	//private static Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);
	
	@Autowired
	private SpringJpaUserRepository springJpaUserRepository;
	
	@Override
	public boolean save(User user) {
		springJpaUserRepository.save(user);
		return true;
	}
	
	@Override
	public boolean remove(Long id) {
		springJpaUserRepository.deleteById(id);
		return true;
	};

	
	@Override
	public List<User> getAll(){
		
		return (List<User>) springJpaUserRepository.findAll();
	}
	@Override
	public User getById(Long id) {
		return springJpaUserRepository.findById(id).get();
	}
	

	@Override
	public User getByName(String login) {
		return springJpaUserRepository.findByLogin(login);
	}

}
