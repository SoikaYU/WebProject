package com.example.demo.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.example.demo.model.Station;



@Component
public class StationMapper implements RowMapper<Station>{

	@Override
	public Station mapRow(ResultSet rs, int rowNum) throws SQLException {
		Station station = new Station();
		station.setId(rs.getLong("id"));
		station.setName(rs.getString("name"));
		station.setCodeStation(rs.getInt("codeStation"));
		
		
		return station;
	}

}
