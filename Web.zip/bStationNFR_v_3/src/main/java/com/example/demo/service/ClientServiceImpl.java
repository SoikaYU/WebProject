package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Client;
import com.example.demo.model.Station;
import com.example.demo.repository.SpringJpaClientsRepository;
import com.example.demo.repository.SpringJpaStationRepository;

@Service
public class ClientServiceImpl implements ClientService{

	@Autowired
	private SpringJpaClientsRepository springJpaClientsRepository;
	
	@Override
	
	public boolean remove(Client client) {
		springJpaClientsRepository.delete(client);
		return true;
	}

	@Override
	public List<Client> getAll() {
		springJpaClientsRepository.findAll();
		return null;
	}

	@Override
	public Client getById(Long id) {
		return springJpaClientsRepository.findById(id).get();
		
	}

	@Override
	public boolean save(Client client, Station station) {
		client.setStation(station);
		springJpaClientsRepository.save(client);
		return false;
	}

	@Override
	public boolean remove(Long id) {
		springJpaClientsRepository.deleteById(id);
		return false;
	}

	@Override
	public Client getByName(String name) {
		
		return springJpaClientsRepository.findAllByName(name);
	}

}
