package com.example.demo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Client;
import com.example.demo.model.Station;



@Repository
public interface SpringJpaStationRepository extends CrudRepository<Station, Long>{

	List<Station> findAllByNameContains(String name);
	
	List<Station> findAllByName(String name);
	List<Station> findFirst3By();
	Optional<Station> findById(Long id);

	void deleteById(Long id);

	void save(Client client);

	
	
	
}
