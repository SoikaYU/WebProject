package com.example.demo.controller;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.stereotype.Controller;
import com.example.demo.model.User;
import com.example.demo.service.UserService;

@Controller
@SessionAttributes(value = "user")
public class UserController {

	private static Logger logger = LoggerFactory.getLogger(UserController.class);

	@Autowired
	private UserService userService;
	
	
	@GetMapping("/")
	
	public String startPage(Model model) {
		User user = new User();
		//List<User> users = userService.getAll();
		model.addAttribute("user", user);
		logger.info("show start page");
		return "index";
	}
	
	@PostMapping("/main")
	public String enter(@Valid @ModelAttribute User user, BindingResult res, Model model, HttpSession session) {
		if(((User) model.getAttribute("user")).getLogin() == null) {
			return "redirect:/";
		}
		if(res.hasErrors()) {
			return "index";
		}
		User userE = new User();
		userE = userService.getByName(user.getLogin());
		if(userE == null) {
			model.addAttribute("erEnter", "errorLogin");
			return "index";
		} else if(!(userE.getPassword().equals(user.getPassword()))) {
			model.addAttribute("erEnter", "errorPassword");
			return "index";
		}
		model.addAttribute("user", userE);
		return "main";
	}
	
	@GetMapping("/main")
	public String goToMain(Model model, HttpSession session) {
		if(((User) model.getAttribute("user")).getLogin() == null) {
			return "redirect:/";
		}
		User user = (User) session.getAttribute("user");
		if(user.getLogin().isEmpty()) {
			return "redirect:/";
		}
		return "main";
	}
	
	@GetMapping("/reg")
	public String goReg(Model model) {
		return "reg";
	}
	
	@PostMapping("/reg")
	public String doReg(@Valid @ModelAttribute User user, BindingResult res, Model model) {
		if(res.hasErrors()) {
			return "reg";
		}
		User userReg = new User();
		userReg = userService.getByName(user.getLogin());
		if(userReg == null) {
			if(user.getLogin().length() > 3 && user.getPassword().length() > 5) {
				userService.save(user);
			model.addAttribute("erEnter", "sucRegistration");
			return "index";
			}
		} else  {
			model.addAttribute("erEnter", "loginIsBusy");
			return "reg";
		}
		return "reg";
	}
	
	
	@GetMapping("/contacts")
	public String goToOptional(Model model) {
		if(((User) model.getAttribute("user")).getLogin() == null) {
			return "redirect:/";
		}
		return "contacts";
	}
	
	@GetMapping("/add")
	public String addPage(Model model) {
		if(((User) model.getAttribute("user")).getLogin() == null) {
			return "redirect:/";
		}
		model.addAttribute("user", new User());
		return "addHTML";
	}

	@PostMapping("/add")
	public String add(@Valid @ModelAttribute User user, BindingResult res, Model model) {
		if(((User) model.getAttribute("user")).getLogin() == null) {
			return "redirect:/";
		}
		if(res.hasErrors()) {
			return "addHTML";
		}
		userService.save(user);
		return "redirect:/";
	}

	

	@GetMapping("/update/{id}")
	public String updatete(@PathVariable Long id, Model model) {
		User user = userService.getById(id);
		model.addAttribute("user", user);
		return "addHTML";
	}
	
	@GetMapping("/delete/{id}")
	public String delete(@PathVariable Long id) {
		userService.remove(id);
		return "redirect:/";
	}
	
	@GetMapping("/info/{id}")
	public String info(@PathVariable Long id, Model model) {
		User user = userService.getById(id);
		model.addAttribute("user", user);
		return "info";
	}
	
	@GetMapping("/escape")
    public String confirmation(SessionStatus status) {
        status.setComplete();
        return "redirect:/";
    }

}
