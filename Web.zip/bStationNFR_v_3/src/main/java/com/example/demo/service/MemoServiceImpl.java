package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Memo;
import com.example.demo.repository.MemoRepository;

@Service
public class MemoServiceImpl implements MemoService{

	@Autowired
	private MemoRepository memoRepository;
	
	@Override
	public boolean save(Memo memo) {
		memoRepository.save(memo);
		return true;
	}

	@Override
	public boolean remove(Long id) {
		memoRepository.deleteById(id);
		return false;
	}

	@Override
	public List<Memo> getAll() {
		
		return (List<Memo>) memoRepository.findAll();
	}

	@Override
	public Memo getByNumber(Long number) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Memo getById(Long id1) {
		
		return memoRepository.findById(id1).get();
	}

}
