package com.example.demo.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.query.criteria.internal.expression.function.AggregationFunction.MIN;
import org.springframework.beans.factory.annotation.Value;

@Entity
@Table(name = "memo")
public class Memo {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	@NotNull
	private Long number;
	@NotEmpty
	private String nameStation;
	@NotEmpty
	private String nameClient;
	@NotNull
	@Min(11111111)
    @Max(99999999)
	private int numberWagon;
	
	private Date firstDate;
	
	private Date secondDate;
	
	private String maker;
	
	private boolean isClosed;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getNumber() {
		return number;
	}

	public void setNumber(Long number) {
		this.number = number;
	}

	public String getNameStation() {
		return nameStation;
	}

	public void setNameStation(String nameStation) {
		this.nameStation = nameStation;
	}

	public String getNameClient() {
		return nameClient;
	}

	public void setNameClient(String nameClient) {
		this.nameClient = nameClient;
	}

	public int getNumberWagon() {
		return numberWagon;
	}

	public void setNumberWagon(int numberWagon) {
		this.numberWagon = numberWagon;
	}

	public Date getFirstDate() {
		return firstDate;
	}

	public void setFirstDate(Date firstDate) {
		this.firstDate = firstDate;
	}

	public Date getSecondDate() {
		return secondDate;
	}

	public void setSecondDate(Date secondDate) {
		this.secondDate = secondDate;
	}

	public String getMaker() {
		return maker;
	}

	public void setMaker(String maker) {
		this.maker = maker;
	}

	public boolean isClosed() {
		return isClosed;
	}

	public void setClosed(boolean isClosed) {
		this.isClosed = isClosed;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((firstDate == null) ? 0 : firstDate.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + (isClosed ? 1231 : 1237);
		result = prime * result + ((maker == null) ? 0 : maker.hashCode());
		result = prime * result + ((nameClient == null) ? 0 : nameClient.hashCode());
		result = prime * result + ((nameStation == null) ? 0 : nameStation.hashCode());
		result = prime * result + ((number == null) ? 0 : number.hashCode());
		result = prime * result + numberWagon;
		result = prime * result + ((secondDate == null) ? 0 : secondDate.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Memo other = (Memo) obj;
		if (firstDate == null) {
			if (other.firstDate != null)
				return false;
		} else if (!firstDate.equals(other.firstDate))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (isClosed != other.isClosed)
			return false;
		if (maker == null) {
			if (other.maker != null)
				return false;
		} else if (!maker.equals(other.maker))
			return false;
		if (nameClient == null) {
			if (other.nameClient != null)
				return false;
		} else if (!nameClient.equals(other.nameClient))
			return false;
		if (nameStation == null) {
			if (other.nameStation != null)
				return false;
		} else if (!nameStation.equals(other.nameStation))
			return false;
		if (number == null) {
			if (other.number != null)
				return false;
		} else if (!number.equals(other.number))
			return false;
		if (numberWagon != other.numberWagon)
			return false;
		if (secondDate == null) {
			if (other.secondDate != null)
				return false;
		} else if (!secondDate.equals(other.secondDate))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Memo [id=" + id + ", number=" + number + ", nameStation=" + nameStation + ", nameClient=" + nameClient
				+ ", numberWagon=" + numberWagon + ", firstDate=" + firstDate + ", secondDate=" + secondDate
				+ ", maker=" + maker + ", isClosed=" + isClosed + "]";
	}

	
}
