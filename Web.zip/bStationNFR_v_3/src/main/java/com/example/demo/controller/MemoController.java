package com.example.demo.controller;


import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.example.demo.model.Memo;
import com.example.demo.model.Station;
import com.example.demo.model.User;
import com.example.demo.service.ClientService;
import com.example.demo.service.MemoService;
import com.example.demo.service.StationService;

@Controller
@SessionAttributes(value = "user")
public class MemoController {
	
	@Autowired
	private ClientService clientsService;
	
	@Autowired
	private StationService stationService;
	
	@Autowired
	private MemoService memoService;
	
	@GetMapping("/memo")
	public String goToKalk(Model model) {
		if(((User) model.getAttribute("user")).getLogin() == null) {
			return "redirect:/";
		}
		Memo memo = new Memo();
		model.addAttribute("memo", memo);
		List<Memo> memos = memoService.getAll();
		model.addAttribute("memos", memos);
		model.addAttribute("stations", stationService.getAll());
		model.addAttribute("clients", clientsService.getAll());
		return "memo";
	}
	
	@PostMapping("/createMemo")
	public String createMemo(@Valid @ModelAttribute Memo memo, BindingResult res, Model model) {
		if(((User) model.getAttribute("user")).getLogin() == null) {
			return "redirect:/";
		}
		if(res.hasErrors()) {
			return "memo";
		}
		memoService.save(memo);
		List<Memo> memos = memoService.getAll();
		model.addAttribute("memo", new Memo());
		model.addAttribute("memos", memos);
		
		return "memo";
	}
	@GetMapping("/deleteMemo/{id1}")
	public String deleteMemo(@PathVariable Long id1, Model model) {
		if(((User) model.getAttribute("user")).getLogin() == null) {
			return "redirect:/";
		}
		memoService.remove(id1);
		return "redirect:/memo";
	}
	
	@GetMapping("/showMemo/{id1}")
	public String showMemo(@PathVariable Long id1, Model model) {
		if(((User) model.getAttribute("user")).getLogin() == null) {
			return "redirect:/";
		}
		Memo showMemo = memoService.getById(id1);
		
		model.addAttribute("showMemo", showMemo);
		return "showMemo";
	}
	
	
}
