package com.example.demo.component;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

 @Bean
 public FilterRegistrationBean < MyFilter > filterRegistrationBean() {
  FilterRegistrationBean < MyFilter > registrationBean = new FilterRegistrationBean<MyFilter>();
  MyFilter customURLFilter = new MyFilter();
System.out.println("Create");
  registrationBean.setFilter(customURLFilter);
  registrationBean.addUrlPatterns("/info/*");
  registrationBean.addUrlPatterns("/main/*");
  registrationBean.addUrlPatterns("/kalk/*");
  registrationBean.addUrlPatterns("/memo/*");
  registrationBean.addUrlPatterns("/raschet/*");
  registrationBean.addUrlPatterns("/showMemo/*");
  registrationBean.addUrlPatterns("/reg/*");
  registrationBean.addUrlPatterns("/contacts/*");
  registrationBean.addUrlPatterns("/addStation/*");
  registrationBean.addUrlPatterns("/add/*");
  registrationBean.addUrlPatterns("/update/*");
  registrationBean.addUrlPatterns("/delete/*");
  registrationBean.addUrlPatterns("/searchByName/*");
  registrationBean.addUrlPatterns("/addSt/*");
  registrationBean.addUrlPatterns("/updateStation/*");
  registrationBean.addUrlPatterns("/deleteSt/*");
  registrationBean.addUrlPatterns("/addClients/*");
  registrationBean.addUrlPatterns("/updateCl/*");
  registrationBean.addUrlPatterns("/deleteCl/*");
  registrationBean.addUrlPatterns("/kalkP/*");
  registrationBean.addUrlPatterns("/createMemo/*");
  registrationBean.addUrlPatterns("/deleteMemo/*");
  registrationBean.addUrlPatterns("/showMemo/*");
  return registrationBean;
  
 }
}
