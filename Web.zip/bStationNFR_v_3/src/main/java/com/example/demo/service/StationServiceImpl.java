package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Station;
import com.example.demo.repository.SpringJpaStationRepository;


@Service
public class StationServiceImpl implements StationService{
	
	@Autowired
	private SpringJpaStationRepository springJpaStationRepository;

	@Override
	public boolean save(Station station) {
		springJpaStationRepository.save(station);
		return true;
	}

	@Override
	public boolean remove(Long id) {
		springJpaStationRepository.deleteById(id);
		return false;
	}

	@Override
	public List<Station> getAll() {
		
		return (List<Station>) springJpaStationRepository.findAll();
	}

	@Override
	public Optional<Station> getById(Long id) {
		
		return springJpaStationRepository.findById(id);
	}

	@Override
	public List<Station> findAllByName(String word) {
		return springJpaStationRepository.findAllByName(word);
		
	}

	@Override
	public List<Station> findAllByNameContains(String name) {
		
		return springJpaStationRepository.findAllByNameContains(name);
	}

	@Override
	public List<Station> getByName(String name) {
		return null;
		
	}

	@Override
	public List<Station> findFirst3By() {
		// TODO Auto-generated method stub
		return springJpaStationRepository.findFirst3By();
	}

	
	
	

	

	
}
