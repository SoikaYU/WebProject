package com.example.demo.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.example.demo.model.Client;
import com.example.demo.model.Memo;
import com.example.demo.model.User;

@Component
public class MemoMapper implements RowMapper<Memo>{

	@Override
	public Memo mapRow(ResultSet rs, int rowNum) throws SQLException {
		Memo memo = new Memo();
		memo.setId(rs.getLong("id"));
		memo.setNumber(rs.getLong("number"));
		memo.setNameStation(rs.getString("name_station"));
		memo.setNameClient(rs.getString("name_client"));
		memo.setNumberWagon(rs.getInt("number_wagon"));
		memo.setFirstDate(rs.getDate("first_date"));
		memo.setSecondDate(rs.getDate("second_date"));
		memo.setMaker(rs.getString("maker"));
		memo.setClosed(rs.getBoolean("is_closed"));
		return memo;
	}

}
