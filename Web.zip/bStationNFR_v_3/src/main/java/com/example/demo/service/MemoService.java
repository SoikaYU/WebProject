package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Memo;

public interface MemoService {
	
	boolean save(Memo memo);
	
	boolean remove(Long id);
	
	List<Memo> getAll();
	
	Memo getByNumber(Long number);

	Memo getById(Long id1);

}
